package com.gamingroom;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * A simple class to hold information about a game
 * 
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a game is
 * created.
 * </p>
 * 
 * @author coce@snhu.edu
 *
 */
public class Game extends Entity {

	// List of teams for this game.   Initialize to prevent null access errors
	private List<Team> teams = new ArrayList<Team>();
	


	/**
	 * Constructor with an identifier and name
	 */
	public Game(long id, String name) {
		this.id = id;
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		
		return "Game [id=" + id + ", name=" + name + "]";
	}
	
	public Team addTeam(String name) {
		Team tempTeam;
		Team nullTeam = null;
		boolean uniqueName = true;
			
		// Instantiate the iterator for teams
		Iterator<Team> it = teams.iterator();
		
		// Loop through the values of the iterator and compare against the 
		// passed name value.
		while(it.hasNext()) {
			tempTeam = it.next();
			if (tempTeam.name == name) {
				// Matched the name, so not unique
				uniqueName = false;
			}
		}
		// After iterating through, if the name is still not unique display an error and re
		// prompt.
		// If it is unique then it will exit the parent while loop.
		if (uniqueName == false) {
			System.out.println("Name already in use.  Try a different name.");
			return nullTeam;
		}
		
		// If we get here the user has entered a unique name.   Find the next id and name and 
		// add to the List.
		tempTeam = new Team(GameService.getNextTeamId(), name);
		
		teams.add(tempTeam);
		
		return tempTeam;

	}

}
