package com.gamingroom;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity {
	// List of players for this team.   Initialize to prevent null access errors
	private List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
	
	/**
	 * 
	 * @param name
	 * @return Player object
	 */
	public Player addPlayer(String name) {
		Player tempPlayer;
		Player nullPlayer = null;
		boolean uniqueName = true;
		
		// Instantiate the iterator for players
		Iterator<Player> it = players.iterator();
		
		// Loop through the values of the iterator and compare against the 
		// passed name value.
		while(it.hasNext()) {
			tempPlayer = it.next();
			if (tempPlayer.name == name) {
				// Matched the name, so not unique
				uniqueName = false;
			}
		}
		// After iterating through, if the name is still not unique display an error and re
		// prompt.
		// If it is unique then it will exit the parent while loop.
		if (uniqueName == false) {
			System.out.println("Name already in use.  Try a different name.");
			return nullPlayer;
		}
		
		// If we get here the user has entered a unique name.   Find the next id and name and 
		// add to the List.
		tempPlayer = new Player(GameService.getNextPlayerId(), name);
		
		players.add(tempPlayer);
		
		return tempPlayer;
	}
}
